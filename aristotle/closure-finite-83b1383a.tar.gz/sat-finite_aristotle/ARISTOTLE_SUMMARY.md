# Summary of changes for run 26ef1a93-bdf3-497f-867c-bd64600f00d1
`Redgrep.closure_finite` in `Bounds.lean` is now fully proved, sorry-free, and depends only on the standard axioms (`propext`, `Classical.choice`, `Quot.sound`). The statement in `Bounds.lean` was not altered — it is discharged by `derivs_range_finite`.

**Approach.** Finiteness is reduced to a *saturation principle*: a set of states `P` is `Sat U P` when its character classes are bounded by a fixed alphabet `U` and it is closed under one-character derivatives, word derivatives, immediate subterms, the suffixes of its concatenation chains, and the "head step" a derivative of a concatenation performs. Such a set is finite, and it contains every state reachable from any of its members (`Sat.derivs_mem`), so exhibiting one for each regex gives the result. The argument is purely structural — it uses no ACI canonicity, so it applies to arbitrary (possibly non-canonical) input terms.

**Work completed this session** (building on the infrastructure files added earlier: `DerivCanon.lean`, `ClsBound.lean`, `ClosureSpan.lean`, `SatPool.lean`, `SatCases.lean`, `ChainPool.lean`):
- `SatSeq.lean` — saturated pools for the two hard constructors, concatenation (`exists_sat_seq`) and Kleene star (`exists_sat_rep`), both instances of the chain machinery in `ChainPool.lean`.
- `SatMain.lean` — `reUniv`/`REOK` (the alphabet bounding all classes of a term, with monotonicity and `reOK_reUniv`), the structural induction `exists_sat_of` combining the nine per-constructor pool constructions, and `exists_sat_set`.
- `ClosureSat.lean` — rewritten to sit on the new development and prove `derivs_range_finite` (statement unchanged, as `Bounds.lean` consumes it).
- `lakefile.toml` — new libraries registered as build targets; minor lint warnings in the new files cleaned up.

**Untouched, as required:** every other `sorry` (all of `Correctness.lean`, and `closure_ncard_le` / `closure_ncard_le_canon` at `Bounds.lean:87,93`) is left exactly as it was, and no pre-existing statement or definition was modified. The whole project builds successfully.