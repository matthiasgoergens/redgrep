# Summary of changes for run 4c06f946-99c9-42f5-9346-b961e6310281
## What was done

**1. The program: `deriv`'s `invHom` case is implemented, total and computable.**

The obstacle was that "derive by the image string" applies `deriv` to the results of `deriv`. I broke the cycle by adding a genuine **word derivative** `Redgrep.derivW : List Char → RE → RE` in `Core.lean`, defined by recursion on the *regex* (with the word shrinking only in the `rep` case), so it never calls `deriv`:

- `seq`: split the word at every position — first factor consumes all of it, or it matches a prefix `u.take i` and the second factor consumes `u.drop i`;
- `rep`: some proper prefix `u.take i` is a whole number of iterations and the straddling chunk begins with `u.drop i`;
- `invHom`: `derivW u (invHom h r) = invHom h (derivW (u.flatMap h) r)`.

Termination is by well-founded recursion on the lexicographic measure `(sizeOf r, u.length)`; the definition is computable (verified by `#eval` on `invHom` examples, and `decide` works on concrete membership goals). `deriv` is then still plain structural recursion, with the single new equation `deriv c (invHom h r) = invHom h (derivW (h c) r)`. Every other case is character-for-character the original, and I recorded all nine equations of `deriv` as `rfl` simp lemmas in `Core.lean` so this is machine-checked.

**2. The four theorems in `Correctness.lean` are proved exactly as stated** — `nullable_correct`, `lang_deriv`, `deriv_correct`, `matchRE_correct` — with no `sorry` and no new axioms (`propext`, `Classical.choice`, `Quot.sound` only). The engine's key new lemma is `lang_derivW : lang (derivW u r) = derivW u (lang r)`, proved by functional induction; it rests on `kstar_split`, a Kleene-star splitting lemma proved by induction on the chunk decomposition. `Statements.lean` was not modified.

One unavoidable edit to `Semantics.lean`: it uses `_root_.invHom`, which is defined in `Statements.lean` but was not imported, so the file did not compile on its own. I added `import Statements` (and a comment saying so); nothing else in that file changed.

**3. Amendment — proposals, with equivalence proofs, in the new `Proposals.lean`** (added as a library in `lakefile.toml`; everything in it builds):

- `matchW r s = nullable (derivW s r)`, matching by one word derivative instead of a fold, proved correct (`matchW_correct`) and equal to the existing matcher (`matchW_eq_matchRE`);
- `lang_derivW_singleton` (`derivW [c]` agrees with `deriv c`) and `derivW_append_lang` (word derivatives compose), which together argue for making `derivW` the engine's primitive — the relevant point for a planned DFA `machine` node, whose word derivative is just running the automaton;
- `decidableMemLang`, a `Decidable (s ∈ lang r)` instance obtained from `matchRE_correct`, the cheapest evidence-carrying step (demonstrated with a `decide` example);
- a closing comment block with unproved suggestions: generalising the alphabet from `Char`, how a `machine` constructor fits the `derivW` shape, a `DecidablePred` form of `sym`, smart constructors, and parse-witness variants (noting that `kstar_split` already yields the split point a `rep` witness needs).

A clean rebuild of the whole project succeeds; a search confirms no `sorry`, `axiom`, or `@[implemented_by]` anywhere. All work is committed and pushed.