# Summary of changes for run ae27720d-32a5-4fe4-b490-c5e923c72b87
All three sorries in `Correctness.lean` are now closed; the project builds cleanly with no `sorry`/`admit` and no new axioms (each theorem depends only on `propext`, `Classical.choice`, `Quot.sound`).

What was proved:
- `Redgrep.nullable_correct` — structural induction on the regex, with each case reduced to membership of `[]` in the corresponding language operation (union/intersection split pointwise, concatenation via `Language.mem_mul`, star via `Language.nil_mem_kstar`, complement flipping).
- `Redgrep.deriv_correct` — proved through a new auxiliary language-level lemma `Redgrep.lang_deriv : lang (deriv c r) = deriv1 c (lang r)`, whose interesting cases are exactly the laws already available in `Statements.lean`: `deriv1_inter` for `cut`, the definitional dual for `alt`, `deriv1_compl` for `not`, `deriv1_mul` for `seq` (its `[] ∈ L₁` guard discharged by `nullable_correct`), and `deriv1_kstar` for `rep`; `sym`/`eps`/`nil` are direct unfolding. `deriv_correct` is then the pointwise reading of that equality.
- `Redgrep.matchRE_correct` — induction on the input string generalising the regex: base case is `nullable_correct`, step case is `deriv_correct`.

No definition in `Core.lean` or `Semantics.lean` was modified, and no statement was weakened. The only additions to `Correctness.lean` are the proofs, an `open Language Computability` line, and the auxiliary lemma `lang_deriv` (the original `deriv_correct` docstring was kept attached to `deriv_correct`). Work is committed and pushed.