# Summary of changes for run 3ba0631d-54b9-4751-84fd-f0aad76fe877
All eight theorems in `Statements.lean` are now proved; the file builds cleanly with no `sorry` and uses only the standard axioms (`propext`, `Classical.choice`, `Quot.sound`).

Proved:
- `deriv1_inter`, `deriv1_compl`: the derivative commutes with intersection and complement.
- `deriv1_mul`: derivative of a concatenation, splitting on whether the first factor accepts the empty word.
- `deriv1_kstar`: derivative of a Kleene star, via the nonempty-first-chunk decomposition (valid even when `[] ∈ L`).
- `kstar_nonempty_chunks`: star membership characterized by decompositions into nonempty chunks.
- `deriv1_invHom`: deriving an inverse-homomorphic image amounts to a left quotient by the image string.
- `revLang_invHom`: reversal commutes with inverse homomorphism via the pointwise-reversed hom (supported by a small private list lemma `reverse_flatMap_reverse`).
- `rightQuot_via_rev`: right quotient by a suffix expressed through reversal and left quotient.

Two purely technical adjustments were needed for the original statements to elaborate, neither of which changes any meaning: the header now opens the `Computability` scope (where the Kleene-star notation `∗` lives), and `deriv1_mul` is preceded by `open Classical in` so that the `if [] ∈ L₁ then … else ⊥` in its statement elaborates without imposing a decidability hypothesis. No definitions or statements were weakened, and no axioms were added. The work is committed and pushed.