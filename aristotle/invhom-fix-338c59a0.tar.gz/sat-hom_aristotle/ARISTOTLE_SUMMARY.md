# Summary of changes for run 166ca6aa-50bf-4015-a0f4-50303da82f21
Implemented the repair specified in CONTRACT.md; the whole project builds and the only remaining `sorry`s are the two pre-existing ones in `Bounds.lean` (`closure_ncard_le`, `closure_canon_ncard_le`), which were out of scope.

**1. New hom normal form (Core.lean).**
- Added `homDedupKeys`: deduplication of an association list **by key**, keeping the FIRST binding for each key — the one `applyHom` resolves to.
- Moved `homNorm` into `Core.lean` and redefined it as: dedup by key → drop identity entries → sort → dedup pairs.
- `invHom_` is now simply `if homNorm h = [] then r else .invHom (homNorm h) r` (with `nil` collapsing as before).
- Added `homDedupKeys_sublist` and `homNorm_subperm` (the sub-permutation fact the saturation layer needs).

**2. The contract, proved (REOrder.lean).**
`homNorm_applyHom (h) (c) : applyHom (homNorm h) c = applyHom h c` (plus the funext form `homNorm_applyHom_eq`). Supporting API, all proved: `applyHom_eq_of_mem`, `applyHom_eq_self`, `applyHom_congr`, `applyHom_filter_ne`, `applyHom_homDedupKeys`, `applyHom_filter_id`, `homDedupKeys_keys_nodup`, `homDedupKeys_eq_self`, `homNorm_perm`, `mem_homNorm`, `homNorm_keys_nodup`, `homNorm_nodup`, `homNorm_sorted`, `homNorm_idem`.

**3. Broken lemma layer repaired.** `invHom_eq_ite`, `mem_homNorm` (now stated against `homDedupKeys h`), `homNorm_idem`, and `SatCases.invHom_cases` (re-proved via `homNorm_subperm`). The ACI layer (`isCanon_invHom_`, `invHom_eq_self`) needed no change.

**4. Unguarded engine theorems.** In `Engine.lean`: `lang_invHom_smart`, `lang_derivW_eq`, `lang_deriv_eq`, `matchRE_iff` — all with no side condition. In `Correctness.lean` the originally-stated theorems are restored verbatim and proved: `lang_derivW`, `lang_deriv`, `deriv_correct`, `matchRE_correct`, `lang_invHom_`, and additionally `canon_correct` (also previously refuted). Axiom check on each: only `propext`, `Classical.choice`, `Quot.sound`.

**5. Housekeeping.** Deleted `HomStable`, `HomWF`, `HomsStable` and the whole hereditary-stability section, all `*_of_stable`/`*_of_homsStable` variants and all `not_*` refutations. Module docstrings in `Core.lean`, `Engine.lean`, `SmartLang.lean` and `Correctness.lean` now record that the duplicate-key counterexample is what motivated the dedup-by-key invariant. `h₀`/`r₀` are kept in `Correctness.lean` as a small regression-test section proving `homNorm h₀ = []`, `invHom_ h₀ r = r`, `lang r₀ = {"a"}`, `matchRE r₀ "a" = true` and `matchRE r₀ "aa" = false` — i.e. the old unsoundness is gone.

`Semantics.lean`, `Statements.lean`, `Bounds.lean` (including `closure_finite`) were not modified; no statements were weakened and no axioms were added.