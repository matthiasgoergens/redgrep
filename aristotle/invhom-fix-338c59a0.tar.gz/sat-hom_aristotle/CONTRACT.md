# The bug you found, and the fix we want

Your counterexample is correct and valuable: with
`h₀ = [('a', ['a']), ('a', [])]`, `applyHom` takes the FIRST binding
(identity), while `homNorm` filters identity entries and thereby exposes
the shadowed SECOND binding, changing the language.  The engine is
unsound on `invHom` nodes whose association list has duplicate keys.

Note the provenance: this representation mirrors the Haskell original's
`Map Char String`, where keys are unique BY CONSTRUCTION, so the
identity-entry filter is sound there.  The bug is an artefact of
weakening `Map` to an association list.  The right repair is therefore
to restore the missing invariant, not to carry a hypothesis forever.

## Your task

1. Change the implementation of `invHom_` (Core.lean) and `homNorm`
   (REOrder.lean) so that they satisfy this CONTRACT:

       theorem homNorm_applyHom (h) (c) :
           applyHom (homNorm h) c = applyHom h c

   i.e. normalisation must preserve the homomorphism pointwise.  The
   suggested route is to deduplicate by KEY — keeping the FIRST binding
   for each key, which is the one `applyHom` sees — BEFORE filtering
   identity entries (and before sorting/dedup of pairs).  You may pick a
   different implementation if it satisfies the contract; prove the
   contract either way.

2. Repair the lemma-layer proofs the change breaks.

3. Then prove the UNGUARDED engine theorems — `lang_derivW`,
   `lang_deriv`, `deriv_correct`, `matchRE_correct` as originally stated,
   with NO `HomsStable` hypothesis — plus `lang_invHom_` unguarded.

4. Housekeeping: once the unguarded theorems hold, the `not_*`
   refutation theorems and the `*_of_homsStable` variants describe the
   OLD definition and become false/redundant.  DELETE them, leaving a
   comment recording that the duplicate-key counterexample motivated the
   dedup-by-key invariant (keep `h₀`/`r₀` only if a test or comment uses
   them).

Everything else — `lang` in Semantics.lean, Statements.lean, the
statements in Bounds.lean, and the already-proved `closure_finite` —
stays fixed.  Do not weaken any statement; no new axioms.  If the
contract itself is unachievable for some reason, do not paper over it:
say so with a counterexample and propose the alternative.
