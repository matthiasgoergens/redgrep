# Design consultation (prose answers wanted, not proofs)

This is a DESIGN review, not a proof task. Please answer in prose, in a
file ANSWERS.md. No proof effort is expected; do not attempt the sorries.

Context: `Core.lean` is a verified-twin regex engine (union, intersection,
complement, concatenation, star, inverse homomorphism), mirroring a
Haskell implementation. `Semantics.lean` gives the denotation,
`Bounds.lean` states a quantitative state-complexity programme.

1. **Our definitions.** Which caused you the most friction when proving?
   What would you change wholesale if unconstrained — canonicity as a
   predicate vs a subtype vs a quotient type; binary constructors plus a
   `canon` function vs sorted-list fields vs `Finset`; the `Cls`
   representation; the assoc-list homomorphism? Frank criticism wanted.

2. **The bounds programme.** Is a per-constructor `B` over the syntactic
   closure the natural formulation of state complexity, or would you
   state it over a different object — Antimirov partial-derivative sets,
   an NFA construction, closure modulo similarity rather than modulo
   `canon`? Which formulation makes the exponential cases (`seq`, `rep`)
   least painful, and how would you state tightness (a witness family
   with exactly `2^(k+1)` states)?

3. **The next phase: evidence.** The engine should produce typed parse
   witnesses on a match AND structured refutation evidence on a
   non-match, with complement SWAPPING the two (De Morgan duality in the
   types: refuting a union needs both refutations; refuting an
   intersection needs a choice of conjunct). How would you formulate that
   in Lean so proofs stay tractable — one inductive family indexed by the
   regex, two mutually-defined families, refutations as
   membership-implies-False plus structure, or something else? Note that
   concatenation and star have no canonical blame assignment (every split
   of the input is a candidate), so a *refutation disambiguation policy*
   is needed, dual to POSIX longest-match on the success side: where does
   that policy least painfully live — in the type, in a parameter, or in
   a separate normalisation?

4. **Anything else** you would restructure now, before more work stacks
   on these foundations — including the planned `Machine` constructor
   (an embedded DFA as a leaf, whose derivative is a table transition).
